<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to Secure Login System</h1>
        <div class="btn-container"></div>
        <a href="register.php" class="btn">Register with hashing</a> <br><br>
        <a href="register1.php" class="btn">Register without hashing</a><br><br>
        <a href="login.php" class="btn">Login</a>
        </div>
    </div>
</body>
</html>

