<strong?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us</title>
    <link rel="stylesheet" href="style.css">

     <!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style1.css" rel="stylesheet">
        <link href="css/style1.css" rel="stylesheet">

    <!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

<div class="container">
<img src="images/srec2.jpeg" width="23%" height="10%"></img>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsFurni">
        <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            <li class="nav-item active">
                <a class="nav-link" href="home.php">🏠 Home</a>
            </li>
        
            <li><a class="nav-link" href="about-us.php">📜 About-Us</a></li>
            <li><a class="nav-link" href="contact.php">📧 Contact</a></li>
            <li><a class="nav-link" href="articles.php">📰 DataBase - View</a></li>
            <li><a class="nav-link" href="logout.php">🚪 Logout</a></li>
        </ul>

        <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
            <li><a class="nav-link" href="#"><img src="images/user.svg"></a></li>
            
        </ul>
    </div>
</div>
</nav>
</head>
<body>

<!--?php include 'navbar.php'; ?-->

<div class="container">
    <h1>About Us</h1>
   <center><b> <p>Welcome to our website. We are dedicated to providing quality services and creating user-friendly experiences.</p>
    <p>Our team consists of passionate developers and designers committed to delivering the best solutions.</p></b></center>
</div>

<div class="product-section">
			<div class="container">
				<div class="row">
                   <h1>OUR TEAM MEMBER!</h1>
					<!-- Start Column 1 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="#">
							<img src="images/pic1.jpeg" class="img-fluid product-thumbnail">
							<strong class="product-title">S.Veerendra</strong><br>
							<strong class="product-price">23X51A05I6</strong>
							<i><h4 class="branch">Computer Science & Engineering</h4></i>

							<span class="icon-cross">
								<img src="images/user.svg" class="img-fluid">
							</span>
						</a>
					</div>
					<!-- End Column 1 -->
<!-- Start Column 2 -->
<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" >
							<img src="images\pic2.jpeg" class="img-fluid product-thumbnail">
							<strong class="product-title">Y.Hemanth Kumar</strong><br>
							<strong class="product-price">23X51A05N0</strong>
							<i><h4 class="branch">Computer Science & Engineering</h4></i>

							<span class="icon-cross">
								<img src="images/user.svg" class="img-fluid">
							</span>
						</a>
					</div> 
					<!-- End Column 2 -->

					<!-- Start Column 3 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="#">
							<img src="images/pic3.jpeg" class="img-fluid product-thumbnail">
							<strong class="product-title"> B. MADHU BHASKAR REDDY</strong>
							<strong class="product-price">24X55A0502</strong><br>
							<i><h4 class="branch">Computer Science & Engineering</h4></i>

							<span class="icon-cross">
								<img src="images/user.svg" class="img-fluid">
							</span>
						</a>
					</div>
					<!-- End Column 3 -->

					<!-- Start Column 4 -->
					<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
						<a class="product-item" href="#">
						<img src="images/pic4.jpeg" class="img-fluid product-thumbnail">
							<strong class="product-title">P. Raghu Chakravarthi</strong>
							<strong class="product-price">24X55A0517</strong>
							<i><h4 class="branch">Computer Science & Engineering</h4></i>

							<span class="icon-cross">
								<img src="images/user.svg" class="img-fluid">
							</span>
						</a>
					</div>
					<!-- End Column 4 -->


</body>
</html>
