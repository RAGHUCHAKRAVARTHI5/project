<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar with Buttons</title>
    <link rel="stylesheet" href="style1.css">

    <!-- Bootstrap CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style1.css" rel="stylesheet">
        <link href="css/style1.css" rel="stylesheet">
</head>
<body>
    <!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

<div class="container">
<img src="images/srec2.jpeg" width="23%" height="10%"></img>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsFurni">
        <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            <li class="nav-item active">
                <a class="nav-link" href="home.php">🏠 Home</a>
            </li>
        
            <li><a class="nav-link" href="about-us.php">📜 About-Us</a></li>
            <li><a class="nav-link" href="contact.php">📧 Contact</a></li>
            <li><a class="nav-link" href="articles.php">📰 DataBase - View</a></li>
            <li><a class="nav-link" href="logout.php">🚪 Logout</a></li>
        </ul>

        <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
            <li><a class="nav-link" href="#"><img src="images/user.svg"></a></li>
            
        </ul>
    </div>
</div>
    
</nav>
<!-- End Header/Navigation -->

     <div class="container">
        <h1>Welcome to Our Project</h1>
        <h2>Secure Login System using Hashing</h2>
    </div>
    <li><a class="nav-link" href="#"><img src="images/srec1.jpg"></a></li>
    <div class="container">
        <h1>Santhiram Engineering College - Nandyal</h1>
    </div>
</body>
 </html>