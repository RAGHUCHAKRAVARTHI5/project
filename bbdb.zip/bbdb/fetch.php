<?php include("connection.php");
if(isset($_POST['request'])){

    $request = $_POST['request'];

    $query = "SELECT *FROM login WHERE bloodgroup ='request'";
    $result = mysqli_query($conn,$query);
    $count = mysqli_num_rows($result);
?>
<table class="table">
    <?php 
    if($count){
    ?>
                    <thead> <tr>
                        <th>Rollno </th>
                        <th>Name   </th>
                        <th>branch   </th>
                        <th>bloodgroup</th>
                        <th>gender</th>
                        <th>mobile</th>
                        <th>email</th>
                        <th>address</th>
                        </tr>
                     <?php 
                        }else{
                            echo "Sorry no record found";
                        }
                     ?>
                    </thead>
                </tbody>
                    </php
                    while($row = mysqli_fetch_assoc($result)){
                        ?>
                        <tr>
                        <td><?php echo $row['rollno']?></td>
                        <td><?php echo $row['Name']?></td>
                        <td><?php echo $row['branch']?></td>
                        <td><?php echo $row['bloodgroup']?></td>
                        <td><?php echo $row['gender']?></td>
                        <td><?php echo $row['mobile']?></td>
                        <td><?php echo $row['email']?></td>
                        <td><?php echo $row['address']?></td>
                        </tr>
                        <?php
                           }
                           ?>
</table>