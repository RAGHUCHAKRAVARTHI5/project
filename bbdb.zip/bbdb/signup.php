<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />


    <!-- website font  -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />

    <title>Sign Up</title>
</head>
<style> 
.box
{
    width:100%;
    max-width:600px;
    background-color:#f9f9f9;
    border:1px solid #ccc;
    border-radius:5px;
    padding:16px;
    margin:0 auot;
}
.error
{
    color:red;
    front-weight:700;
}
</style>
    

<body>

    <!-- Navbar 1 Start -->
    <section id="Nav1">
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <div class="container">
                <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                            <i class="fas fa-phone-volume" style="border-right: 1px solid gray;"> + 098 66 308475
                                &nbsp; &nbsp; </i>
                        </li>
                        <li class="nav-item">
                            <i class="far fa-envelope" style="padding-left: 15px;"> principal@srecnandyal.edu.in</i>
                        </li>
                    </ul>
                </div>
                <div class="mx-auto order-0 navbar-brand mx-auto">
                    <a href="https://www.instagram.com/srecndl/" target="_blank"><i
                            class="fab fa-instagram github">&nbsp;&nbsp;</i></a>
                    <a href="https://www.facebook.com/SanthiramEngineeringCollege/"  target="_blank"><i
                            class="fab fa-facebook-f facebook">&nbsp;&nbsp;</i></a>
                    <a href="https://www.youtube.com/channel/UCHItAgvPwN8e8sJmGppibtw"  target="_blank"><i class="fab fa-youtube">&nbsp;&nbsp;</i></a>
                    <a href="https://www.linkedin.com/school/santhiram-engineering-college-nandyal/?originalSubdomain=in"  target="_blank"><i
                            class="fab fa-linkedin" style="color:white">&nbsp;&nbsp;</i></a>
                </div>
                <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                   <!--<ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link selected" style="border-right: 1px solid gray;" href="#">EN &nbsp;</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="padding-left: 15px;" href="#">AR</a>-->
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <!-- Navbar 1 End -->

    <!-- Navbar 2 Start -->
    <section id="Nav2">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img src="imgs/srec5.jpg" width="18%"></img>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link " href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="About-us.html">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="article.html">Articles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="requests.php">Donations</a>
                    </li>
                    <!---<li class="nav-item">
                        <a class="nav-link" href="who-we-are.html">Who We Are ?</a>-->
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact-us.html">Contact Us</a>
                    </li>
                </ul>
               <!--- <button class="btn signup" onclick= "window.location.href = 'signup.html';">New Account</button>-->
                <button class="btn login" onclick= "window.location.href = 'login.php';">Login</button>
            </div>
        </nav>
    </section>
    <!--- Navbar 2 End -->

    <!-- Navigator Start -->
    <section id="navigator">
        <div class="container">
            <div class="path">
                <div class="path-main" style="color: darkred; display:inline-block;">Home</div>
                <div class="path-directio" style="color: grey; display:inline-block;"> / Sign up</div>
            </div>

        </div>
    </section>
    <!-- Navigator End -->

    <!-- Sign Up Start -->
    
    <section id="sign-up">
        <div class="container">
        <img src="imgs/logo.png" alt="">    
                <form action="" method="GET">
                    <div class="row">
                        <div class="col-md-6">
                            <!--<h2>Roll no:</h2>-->
                            <input type="text" name="roll" value="<?php if(isset($_GET['roll'])){echo $_GET['roll'];} ?>" placeholder="Enter RollNo" class="form-control"
                            required  maxlength="10">
                        </div>
                        <div class="col-md-4">
                           <a href="signup.php"> <button type="search" class="btn btn-primary ">search</button></a>
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        <hr>
                        <?php
                          include 'connection.php';

                          if(isset($_GET['roll']))
                          {
                            $roll=$_GET['roll'];

                             $query ="SELECT  Name FROM login WHERE  rollno='$roll'";
                             $query_run=mysqli_query($conn,$query);

                               if(mysqli_num_rows($query_run)>0)
                            {
                                foreach($query_run as $row)
                              {
                                
                                ?>

                        <div class="form-group=mb-3">
                            <input type="text" name="Name" disabled  value="<?=$row['Name']; ?>" class="form-control">
                        </div>
                        <!--a class="link" href="signup1.php">Contact Us</a-->
                    

                    </form>
                    </div>
                    
    
    <div class="container">
        
        <?php
error_reporting(0);
$db_host="localhost";
$name ="root";
$password="";
$dbname ="bbdb";

$conn=mysqli_connect($db_host, $name, $password, $dbname);
if(!$conn){
    die("connection failed"); 
}
//echo " connected successfully <BR>";

if(isset($_REQUEST['submit'])){
    //echo "submit button is clicked <br>";
  
    $branch = $_REQUEST['branch'];
    $bloodgroup = $_REQUEST['bloodgroup'];
    $gender = $_REQUEST['gender'];
    $mobile = $_REQUEST['mobile'];
    $email = $_REQUEST['email'];
    $address = $_REQUEST['address'];

    


  $sql = "UPDATE login SET branch='$branch',bloodgroup='$bloodgroup',gender='$gender',mobile='$mobile',email='$email',address='$address' WHERE rollno='$roll'";
}?> 
                <form action="" method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <!--<h2>Roll no:</h2>-->
                        <div class="form-group">
                            <label for="branch"></label>
                            <select name="branch" id="branch" name="branch" required class="form-control">
                                <option value="" > Select Branch</option>
                                <option value="Computer Engineering">Computer Engineering</option>
                                <option value="Electronics and Communication Engineering">Electronics and Communication Engineering</option>
                                <option value="Electrical and Electronic Engineering">Electrical and Electronic Engineering</option>
                                <option value="Civil Engineering">Civil Engineering</option>
                                <option value="Mechanical Engineering">Mechanical Engineering</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="bloodgroup"></label>
                            <select name="bloodgroup" id="bloodgroup" required class="form-control">
                            <option value="" > Select Blood Group</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                            </select>
                        </div><br>
                        <div class="form-group">
                            <label for="gender" value="gender" name="gender" id="gender"> Select Gender:</label>
                            <input type="radio" id="gender" name="gender" value="Male">
                            <label for="html">Male</label>
                           <input type="radio" id="css" name="gender" value="Female">
                           <label for="css">Female</label>
                           <input type="radio" id="other" name="gender" value="Other">
                           <label for="css">Other</label>
                        </div>
                        <div class="form-group">
                            <label for="mobile"></label>
                            <input type="text" name="mobile"  placeholder="Enter Mobile" required maxlength="10" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label for="email"></label>
                            <input type="text" name="email" placeholder="Enter Email" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label for="address"></label>
                            <input type=""  name="address" placeholder="Enter Address" class="form-control" >
                        </div>
                        <div class="form-group"><center>
                    <button type="submit" name="submit">SUBMIT</button>
                    </div>
                </form>
                
                 <?php
            if(mysqli_query($conn,$sql)){
              echo "<a href='index.html'><button class='btn'>Submitted</button>";
           }else{
              echo "record  is not saved ";
           } 
          ?>
            <?php
                echo "Go Back ";
                             
                            }
                          }
                          else
                          {
                          echo "no data";
                          }
                      }
                      ?>                              
        </div>
    </section>
          
          
                                          
        </div>
    </section>
                    
       
    <!-- Sign Up End -->

    <!-- Footer Start -->
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="foot-info">
                    <img src="imgs/srec5.jpg" width="350" height="100" alt="">
                        <p>Blood banking is the process that takes place in the lab to make sure 
                            that donated blood, or blood products, are safe before they are used in blood transfusions and other medical procedures. 
                            Blood banking includes typing the blood for transfusion and testing for infectious diseases.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <ul class="menu">
                        <a href="index.html">
                            <li>Home</li>
                        </a>
                        <a href="About-us.html">
                            <li>About Us</li>
                        </a>
                        <a href="#articles">
                            <li>Articles</li>
                        </a>
                        <a href="requests.html">
                            <li>Donations</li>
                        </a>
                        <a href="contact-us.html">
                            <li>Contact Us</li>
                        </a>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="options">
                    <li>
                            <h5>Location</h5>
                            <P><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3844.603272113751!2d78.37555659999998!3d15.505757600000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb5b49a37d3d603%3A0xa5d0919e871eabe8!2sSanthiram%20Engineering%20College(Autonomous)!5e0!3m2!1sen!2sin!4v1743271433760!5m2!1sen!2sin" 
                                width="300" height="150" style="border:2px rgba(100, 249, 66, 0.478);" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
                        </li>
                        <!--<li><img src="imgs/ios1.png" alt=""></li>
                        <li><img src="imgs/google1.png" alt=""></li>-->
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer End -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script type="text/javascript" src="js/swiper.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>