<?php
include 'connection.php';

if(isset($_GET['roll']))
{
    $roll=$_GET['roll'];

    $query ="select name from login where rollno='$roll'";
    $query_run=mysqli_query($conn,$query);

if(mysqli_num_rows($query_run)>0)
{
    foreach($query_run as $row)
    {
        echo $row['name'];
    }

}
else{
    echo "No data";
}

}
?>