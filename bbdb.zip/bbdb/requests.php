<?php 
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />


    <!-- website font  -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />

    <title>Donations</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Helvetica",sans-serif;
        }
        /*.container
  {
    background-color:white;
    border-left: 50px;
    border-right: 50px;

  }*/

table {
    border-collapse: collapse;
    width: 100%;
    background-color: white;
  }
  
  td, th {
    border: 3px solid #dddddd;
    text-align: center;
    padding:6px 20px;
  }
  tr th {
   border: 1px solid #white ;
    text-align: center;
    padding:6px 18px;
    background-color: #ad1e23;
    color:#fff;
  }
  
  tr:hover {
    background-color: #dddddd;
    
  }
  
  .content td, .content th {
      border-top: 1px solid transparent;
      padding: 2px 10px 2px 15px;
  }
        </style>
</head>

<body>

    <!-- Navbar 1 Start -->
    <section id="Nav1">
        <nav class="navbar navbar-expand-md navbar-dark bg-dark">
            <div class="container">
                <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                            <i class="fas fa-phone-volume" style="border-right: 1px solid gray;"> + 098 66 308475
                                &nbsp; &nbsp; </i>
                        </li>
                        <li class="nav-item">
                            <i class="far fa-envelope" style="padding-left: 15px;"> principal@srecnandyal.edu.in</i>
                        </li>
                    </ul>
                </div>
                <div class="mx-auto order-0 navbar-brand mx-auto">
                    <a href="https://www.instagram.com/srecndl/" target="_blank"><i
                            class="fab fa-instagram github">&nbsp;&nbsp;</i></a>
                    <a href="https://www.facebook.com/SanthiramEngineeringCollege/"  target="_blank"><i
                            class="fab fa-facebook-f facebook">&nbsp;&nbsp;</i></a>
                    <a href="https://www.youtube.com/channel/UCHItAgvPwN8e8sJmGppibtw"  target="_blank"><i class="fab fa-youtube">&nbsp;&nbsp;</i></a>
                    <a href="https://www.linkedin.com/school/santhiram-engineering-college-nandyal/?originalSubdomain=in"  target="_blank"><i
                            class="fab fa-linkedin" style="color:white">&nbsp;&nbsp;</i></a>
                </div>
                <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <!--<a class="nav-link selected" style="border-right: 1px solid gray;" href="#">EN &nbsp;</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" style="padding-left: 15px;" href="#">AR</a>-->
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <!-- Navbar 1 End -->

    <!-- Navbar 2 Start -->
    <section id="Nav2">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img src="imgs/srec5.jpg" width="18%"></img>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="About-us.html">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="article.html">Articles</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link selected" href="requests.php">Donations</a>
                    </li>
                    <!--<li class="nav-item">
                        <a class="nav-link" href="who-we-are.html">Who We Are ?</a>-->
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact-us.html">Contact Us</a>
                    </li>
                </ul>
                <button class="btn Donor" onclick= "window.location.href = 'signup.php';">Donor</button>
                <button class="btn login" onclick= "window.location.href = 'login.php';">Login</button>
            </div>
        </nav>
    </section>
    <!-- Navbar 2 End -->

    <!-- Navigator Start -->
    <section id="navigator">
        <div class="container">
            <div class="path">
                <div class="path-main" style="color: darkred; display:inline-block;">Home</div>
                <div class="path-directio" style="color: grey; display:inline-block;"> / Donations</div>
            </div>

        </div>
    </section>
    <!-- Navigator End -->

    <!-- Requests Start -->
    
<div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-4">
              
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-7">

                                <form action="" method="GET">
                                    <div class="input-group mb-3">
                                    
                                        <select name="search" id="" class="form-control"required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>">
                                            <option value="" disabled selected>Select Blood Type</option>
                                            <option value="A+">A+</option>
                                            <option value="A-">A-</option>
                                            <option value="B+">B+</option>
                                            <option value="B-">B-</option>
                                            <option value="AB+">AB+</option>
                                            <option value="AB-">AB-</option>
                                            <option value="O+">O+</option>
                                            <option value="O-">O-</option>
                                         </select>
                                        
                                        <button type="submit" class="btn btn-primary">Search</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-body">
                        <table class="table table-bordered">
                        <tr>
                           <th>Rollno </th>
                           <th>Name   </th>
                           <th>branch   </th>
                           <th>bloodgroup</th>
                           <th>gender</th>
                           <th>mobile</th>
                           <th>email</th>
                           <th>address</th>
                        </tr>
                            <tbody>
                                <?php 
                                    $con = mysqli_connect("localhost","root","","bbdb");

                                    if(isset($_GET['search']))
                                    {
                                        $filtervalues = $_GET['search'];
                                        $query = "SELECT * FROM login WHERE bloodgroup ='$filtervalues' ";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['rollno']; ?></td>
                                                    <td><?= $items['Name']; ?></td>
                                                    <td><?= $items['branch']; ?></td>
                                                    <td><?= $items['bloodgroup']; ?></td>
                                                    <td><?= $items['gender']; ?></td>
                                                    <td><?= $items['mobile']; ?></td> 
                                                    <td><?= $items['email']; ?></td>
                                                    <td><?= $items['address']; ?></td>
                                                
                                              
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
         
            <div class="page-num">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                    <span class="sr-only">Previous</span>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
        </div>
    </section>
    <!-- Requests End -->

    <!-- Footer Start -->
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="foot-info">
                    <img src="imgs/srec5.jpg" width="350" height="100" alt="">
                        <p>Blood banking is the process that takes place in the lab to make sure 
                            that donated blood, or blood products, are safe before they are used in blood transfusions and other medical procedures. 
                            Blood banking includes typing the blood for transfusion and testing for infectious diseases.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <ul class="menu">
                        <a href="index.html">
                            <li>Home</li>
                        </a>
                        <a href="About-us.html">
                            <li>About Us</li>
                        </a>
                        <a href="#articles">
                            <li>Articles</li>
                        </a>
                        <a href="requests.html">
                            <li>Donations</li>
                        </a>
                        <a href="contact-us.html">
                            <li>Contact Us</li>
                        </a>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="options">
                    <li>
                            <h5>Location</h5>
                            <P><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3844.603272113751!2d78.37555659999998!3d15.505757600000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb5b49a37d3d603%3A0xa5d0919e871eabe8!2sSanthiram%20Engineering%20College(Autonomous)!5e0!3m2!1sen!2sin!4v1743271433760!5m2!1sen!2sin" 
                                width="300" height="150" style="border:2px rgba(100, 249, 66, 0.478);" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
                        </li>
                        <!--<li><img src="imgs/ios1.png" alt=""></li>
                        <li><img src="imgs/google1.png" alt=""></li>-->
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer End -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
   
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script type="text/javascript" src="js/swiper.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>

</html>