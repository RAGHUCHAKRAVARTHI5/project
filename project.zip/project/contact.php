<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <link rel="stylesheet" href="style.css">
<!-- Bootstrap CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
		<link href="css/tiny-slider.css" rel="stylesheet">
		<link href="css/style1.css" rel="stylesheet">
        <link href="css/style1.css" rel="stylesheet">

    <!-- Start Header/Navigation -->
		<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

<div class="container">
<img src="images/srec2.jpeg" width="23%" height="10%"></img>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsFurni">
        <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
            <li class="nav-item active">
                <a class="nav-link" href="home.php">🏠 Home</a>
            </li>
        
            <li><a class="nav-link" href="about-us.php">📜 About-Us</a></li>
            <li><a class="nav-link" href="contact.php">📧 Contact</a></li>
            <li><a class="nav-link" href="articles.php">📰 DataBase - View</a></li>
            <li><a class="nav-link" href="logout.php">🚪 Logout</a></li>
        </ul>

        <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
            <li><a class="nav-link" href="#"><img src="images/user.svg"></a></li>
            
        </ul>
    </div>
</div>
</nav>
</head>
<body>

<!--?php include 'navbar.php'; ?-->


<!-- Start Footer Section -->
<footer class="footer-section">
			<div class="container">

				
				<div class="row g-5 mb-5">
				<div class="col-lg-4">
                    <div class="foot-info">
                        <img src="images/srec4.png" width="300" height="150" alt=""><br>
                        <p>The institute has been motivating the students to develop according to their aspirations.
the institute has been trying to understand the students through the ways they grow and develop.
It is important for the institute to understand that every student is different and therefore. will learn in their own ways. 
</p>
                    </div>
						<ul class="list-unstyled custom-social">
							<li><a href="https://www.facebook.com/SanthiramEngineeringCollege/"><span class="fa fa-brands fa-facebook-f"></span></a></li>
							<li><a href="https://www.youtube.com/channel/UCHItAgvPwN8e8sJmGppibtw"><span class="fa fa-brands fa-youtube"></span></a></li>
							<li><a href="https://www.instagram.com/srecndl/"><span class="fa fa-brands fa-instagram"></span></a></li>
							<li><a href="https://www.linkedin.com/school/santhiram-engineering-college-nandyal/?originalSubdomain=in"><span class="fa fa-brands fa-linkedin"></span></a></li>
						</ul>
					</div>

					<div class="col-md-2">
                    <ul class="menu">
									<li><a href="index.php">Home</a></li>
									<li><a href="about-us.php">About-us</a></li>
									<li><a href="contact.php">Contact</a></li>
									<li><a href="articles.php">DataBase View</a></li>
									<li><a href="login.php">Login</a></li>
									<li><a href="logout.php">Logout</a></li>
								</ul>
                </div>

				        <div class="col-md-4">
                            <ul class="c">
                            <li>
                                <h5>Location</h5>
                                <P><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3844.603272113751!2d78.37555659999998!3d15.505757600000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb5b49a37d3d603%3A0xa5d0919e871eabe8!2sSanthiram%20Engineering%20College(Autonomous)!5e0!3m2!1sen!2sin!4v1743271433760!5m2!1sen!2sin" 
									width="450" height="300" style="border:2px rgba(100, 249, 66, 0.478);" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
                             </li>
                             </ul>
                        </div>
						</div>
					</div>

				</div>

				<!--div class="border-top copyright">
					<div class="row pt-4">
						<div class="col-lg-6">
							<p class="mb-2 text-center text-lg-start">Copyright &copy;<script>document.write(new Date().getFullYear());</script>. All Rights Reserved. &mdash; Designed with love by <a href="https://untree.co">Untree.co</a> Distributed By <a hreff="https://themewagon.com">ThemeWagon</a>  <!-- License information: https://untree.co/license/ >
            </p>
						</div>

						<div class="col-lg-6 text-center text-lg-end">
							<ul class="list-unstyled d-inline-flex ms-auto">
								<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>

					</div-->
				</div>

			</div>
		</footer>
		<!-- End Footer Section -->	



</body>
</html>
